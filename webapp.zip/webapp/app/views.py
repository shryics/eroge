from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.shortcuts import render, redirect
import cv2, os
from keras.models import model_from_json
from time import sleep

from .forms import PhotoForm
from .models import Photo


def index(request):
    return HttpResponse("Hello, world. You're at the polls index.")

def post_list(request):
    return render(request, 'app/base.html')



def processing_image(filepath):
    face_cascade = cv2.CascadeClassifier('../data/lbpcascade_animeface.xml')
    sleep(10)
    print(os.listdir("media/app"))
    img = cv2.imread(filepath)

    print('--------------------')
    print(filepath)
    print(os.getcwd())
    print(img)
    print('--------------------')

    # グレースケール変換
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # 顔を検知
    faces = face_cascade.detectMultiScale(gray)
    if len(faces) != 0: # 顔検知時に以下の処理を実行
        for (x,y,w,h) in faces:
            # 検知した顔を矩形で囲む
            #cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
            # 顔画像（グレースケール）
            roi_gray = gray[y:y+h, x:x+w]
            # 顔ｇ増（カラースケール）
            roi_color = img[y:y+h, x:x+w]
            # 顔の中から目を検知
            face = img[y:y+h, x:x+w]


        # 顔画像をリサイズ
        size = 50
        face_resize = face.resize((size, size), resample=0)

        face_resize = face_resize.reshape(1, 2500*3) / 255

        json_string = "app/model_cnn.json"
        model = model_from_json(json_string)
        model.load_weights('app/weights_cnn.h5')
        model.summary();
        # 損失関数，最適化アルゴリズムなどの設定 + モデルのコンパイルを行う
        model.compile(loss='categorical_crossentropy', optimizer='sgd', metrics=['accuracy'])

        # 予測
        pred = model.predict(face_resize)

        return pred
    else:
        return ("Error: Not found face.")






def index(req):
    if req.method == 'GET':
        return render(req, 'app/base.html', {
            'form': PhotoForm(),
            'photos': Photo.objects.all(),  # ここを追加
        }
                      )
    elif req.method == 'POST':
        form = PhotoForm(req.POST, req.FILES)
        if not form.is_valid():
            raise ValueError('invalid form')

        photo = Photo()
        photo.image = form.cleaned_data['image']
        photo.save()

        # # filepath = "media/app" + str(photo.image)
        # # # アップロードされた画像の処理を開始
        # print(processing_image(filepath))
        print()
        print()
        return redirect('/')

def predict():
    print(12341234)
    return 0